from coat.ImageCoating import Coat, Montage
__version__ = '0.3'